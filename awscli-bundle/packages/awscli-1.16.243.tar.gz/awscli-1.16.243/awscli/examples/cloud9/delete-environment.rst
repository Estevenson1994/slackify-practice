**To delete an AWS Cloud9 development environment**

This example deletes the specified AWS Cloud9 development environment. If an Amazon EC2 instance is connected to the environment, also terminates the instance.

Command::

  aws cloud9 delete-environment --environment-id 8a34f51ce1e04a08882f1e811bd706EX

Output::

  None.